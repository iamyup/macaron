#include "GameLayer.h"
#include "GameObject.h"

enum
{
	zBackground = 0,
	zGameObject = 1,
};

bool GameLayer::init()
{
	if (CCLayer::init() == false)
	{
		return false;
	}

	CCSprite* pBackgroundSprite = CCSprite::create("Background.png");
	pBackgroundSprite->setPosition(CCPointZero);
	pBackgroundSprite->setAnchorPoint(ccp(0.0f, 0.0f));
	addChild(pBackgroundSprite, zBackground);

	m_winSize = CCDirector::sharedDirector()->getWinSize();

	StartGame();

	return true;
}

void GameLayer::StartGame()
{
	srand(time(NULL));

	for (int x = 0; x < COLUMN_COUNT; ++x)
	{
		for (int y = 0; y < ROW_COUNT; ++y)
		{
			int type = rand() % TYPE_COUNT;

			GameObject* pGameObject = GameObject::Create(type);
			m_pBoard[x][y] = pGameObject;

			pGameObject->setAnchorPoint(ccp(0.0f, 1.0f));
			pGameObject->setPosition(Common::ComputeXY(x, y));

			addChild(pGameObject, zGameObject);
		}
	}
}

CCScene* GameLayer::scene()
{
	CCScene* pScene = CCScene::create();

	GameLayer* pLayer = GameLayer::create();
	pScene->addChild(pLayer);

	return pScene;
}
