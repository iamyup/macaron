#ifndef PuzzleGame_GameObject
#define PuzzleGame_GameObject

#include "Common.h"

class GameObject : public CCSprite
{
public:
	GameObject();
	~GameObject();

protected:
	static GameObject* create(const char* pszFileName, const CCRect& rect);

public:
	static GameObject* Create(int type);

	int GetType();
	void SetType(int type);

private:
	int m_type;
};

#endif

