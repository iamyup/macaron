#ifndef PuzzleGame_Common
#define PuzzleGame_Common

#include "cocos2d.h"

USING_NS_CC;

#define DESIGN_WIDTH	768.0f
#define DESIGN_HEIGHT	1024.0f

#define ROW_COUNT			8
#define COLUMN_COUNT		8
#define MAX_ROW_COUNT		10

#define TYPE_COUNT			7

#define OBJECT_WIDTH		96
#define OBJECT_HEIGHT		96

class Common
{
public:
	static float ComputeX(float x);
	static float ComputeY(float y);
	static CCPoint ComputeXY(float x, float y);

	static int ComputeBoardX(float x);
	static int ComputeBoardY(float y);
};

#endif
