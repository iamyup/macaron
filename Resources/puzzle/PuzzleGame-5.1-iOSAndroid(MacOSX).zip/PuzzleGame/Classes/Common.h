//
//  Common.h
//  PuzzleGame
//
//  Created by Jae Hyun Roh on 3/29/13.
//
//

#ifndef PuzzleGame_Common_h
#define PuzzleGame_Common_h

#include "cocos2d.h"

USING_NS_CC;

#define DESIGN_WIDTH    768.0f
#define DESIGN_HEIGHT   1024.0f

#endif
