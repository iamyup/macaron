#include "GameLayer.h"

bool GameLayer::init()
{
	if (CCLayer::init() == false)
	{
		return false;
	}

	CCSprite* pBackgroundSprite = CCSprite::create("Background.png");
	pBackgroundSprite->setPosition(CCPointZero);
	pBackgroundSprite->setAnchorPoint(ccp(0.0f, 0.0f));
	addChild(pBackgroundSprite);

	return true;
}

CCScene* GameLayer::scene()
{
	CCScene* pScene = CCScene::create();

	GameLayer* pLayer = GameLayer::create();
	pScene->addChild(pLayer);

	return pScene;
}
