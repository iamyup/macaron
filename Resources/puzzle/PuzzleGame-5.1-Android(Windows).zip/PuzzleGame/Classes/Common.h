#ifndef PuzzleGame_Common
#define PuzzleGame_Common

#include "cocos2d.h"

USING_NS_CC;

#define DESIGN_WIDTH	768.0f
#define DESIGN_HEIGHT	1024.0f

#endif
