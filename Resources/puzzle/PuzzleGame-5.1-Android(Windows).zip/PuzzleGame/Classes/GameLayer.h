#ifndef PuzzleGame_GameLayer
#define PuzzleGame_GameLayer

#include "Common.h"

class GameLayer : public CCLayer
{
public:
	bool init();

	static CCScene* scene();

	CREATE_FUNC(GameLayer);
};

#endif
