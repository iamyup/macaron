#ifndef PuzzleGame_GameLayer
#define PuzzleGame_GameLayer

#include "Common.h"

class GameLayer : public CCLayer
{
public:
	bool init();

	void StartGame();

	static CCScene* scene();

	CREATE_FUNC(GameLayer);

protected:
	CCSprite* m_pBoard[COLUMN_COUNT][MAX_ROW_COUNT];

	CCSize m_winSize;
};

#endif
